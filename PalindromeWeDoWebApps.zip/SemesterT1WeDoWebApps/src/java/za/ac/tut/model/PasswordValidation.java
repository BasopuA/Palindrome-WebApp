/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.model;

/**
 *
 * @author Alex
 * 
 *         String myUsername = request.getParameter("myUsername");
        String myPassword = request.getParameter("myPassword");
        String password = getServletContext().getInitParameter("password");
        String username = getServletContext().getInitParameter("username");
 * 
 */
public class PasswordValidation {
    public boolean isValidated(String myUsername,String username,String myPassword,String password) throws LoginException
    {
        boolean result = false;
        if(myUsername.equals(username) && myPassword.equals(password))
        {
            result = true;
        }
        
        return result;
    }
}
