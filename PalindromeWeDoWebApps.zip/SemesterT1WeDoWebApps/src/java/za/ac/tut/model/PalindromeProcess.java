package za.ac.tut.model;

/**
 *
 * @author Alex
 */
public class PalindromeProcess {
    
    private String reverseDigits;
    
    public boolean isPalindrome(String digits) throws DigitsLengthException {
        // Handle null or empty input
        if (digits == null || digits.isEmpty()) {
            reverseDigits = ""; // or null, depending on your requirement
            return false;
        }
        
        // Reverse the string
        String tempStr = "";
        for (int i = digits.length() - 1; i >= 0; i--) {
            char tempChar = digits.charAt(i);
            tempStr += tempChar;
        }
        
        // Set the reversed string
        reverseDigits = tempStr;
        
        // Check if the original string matches the reversed string
        return digits.equals(tempStr);
    }

    public String getReverseDigits() {
        return reverseDigits;
    }
}