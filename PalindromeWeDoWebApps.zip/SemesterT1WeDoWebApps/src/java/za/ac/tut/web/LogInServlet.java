/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.logging.Level;
import java.util.logging.Logger;
import za.ac.tut.model.LoginException;
import za.ac.tut.model.PasswordValidation;

/**
 *
 * @author Alex
 */
public class LogInServlet extends HttpServlet {

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String myUsername = request.getParameter("myUsername");
        String myPassword = request.getParameter("myPassword");
        String password = getServletContext().getInitParameter("password");
        String username = getServletContext().getInitParameter("username");
        
        PasswordValidation pv = new PasswordValidation();
        
        try {
            boolean valid = pv.isValidated(myUsername, username, myPassword, password);
            if(!valid)
            {
                throw new LoginException("Invalid password or username!!");
            }
            else
            {
                request.getRequestDispatcher("outcome.jsp").forward(request, response);
            }
        } catch (LoginException ex) {
            request.setAttribute("error", ex.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
        
    }

   
}
