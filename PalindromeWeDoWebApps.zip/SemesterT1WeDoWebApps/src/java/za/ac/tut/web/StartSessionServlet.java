/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alex
 */
public class StartSessionServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        String name = request.getParameter("name");
        
        initializeSession(session, name);
        
        request.getRequestDispatcher("palindrome.jsp").forward(request, response);
        
    }
    private void initializeSession(HttpSession session,String name)
    {
        
        Integer numPalandrome = 0;
        Integer numNonPalandrome = 0;
        Integer TotalnumChecked = 0;
        
        session.setAttribute("numPalandrome", numPalandrome);
        session.setAttribute("numNonPalandrome", numNonPalandrome);
        session.setAttribute("TotalnumChecked", TotalnumChecked);
        session.setAttribute("name", name);
        
        
    }

}
