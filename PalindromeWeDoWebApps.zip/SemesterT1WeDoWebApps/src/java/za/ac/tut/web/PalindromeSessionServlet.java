/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.logging.Level;
import java.util.logging.Logger;
import za.ac.tut.model.DigitsLengthException;
import za.ac.tut.model.PalindromeProcess;

/**
 *
 * @author Alex
 */
public class PalindromeSessionServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String digits = request.getParameter("digits");
        String outcome = "";
        
        PalindromeProcess pp = new PalindromeProcess();
        
        try {
            if(digits.length()>3)
            {
                throw new DigitsLengthException("Your Digits are more than 3 please provide 3.");
            }
            
            boolean result = pp.isPalindrome(digits);
            String reverse = pp.getReverseDigits();
            
            session.setAttribute("reverse", reverse);
            session.setAttribute("digits", digits);
            updateSession(session, result, outcome);
            
            request.getRequestDispatcher("check_isPalindrome.jsp").forward(request, response);
        
        
        }catch (DigitsLengthException ex) {
            request.setAttribute("error", ex.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
    private void updateSession(HttpSession session,boolean result,String outcome)
    {
        Integer numPalandrome = (Integer)session.getAttribute("numPalandrome");
        Integer numNonPalandrome = (Integer)session.getAttribute("numNonPalandrome");
        Integer TotalnumChecked = (Integer)session.getAttribute("TotalnumChecked");
        
        if(result)
         {
             outcome= "Is a Palindrome";
             numPalandrome++;
         }
         else
         {
             outcome= "Is NOT a Palindrome";
             numNonPalandrome++;
         }
         
         TotalnumChecked++;
         
        session.setAttribute("numPalandrome", numPalandrome);
        session.setAttribute("numNonPalandrome", numNonPalandrome);
        session.setAttribute("TotalnumChecked", TotalnumChecked);
        session.setAttribute("outcome", outcome);
        
    }
   
}
